/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cargovessel;

import java.util.Scanner;
import java.util.InputMismatchException;

// Encapsulation
class Ship { 
    private String name; 
    private String shipClass; 
    private double tonnage; 
    private int capacity; 

    public Ship(String name, String shipClass, double tonnage, int capacity) { 
        this.name = name;
        this.shipClass = shipClass;
        this.tonnage = tonnage;
        this.capacity = capacity;
    }

    public String getShipInfo() { 
        return String.format("Cargo ship: %s\nClass: %s\nTonnage: %.0f GT\nCapacity: %d TEU",
                name, shipClass, tonnage, capacity);
    }
}

// Derived class from Ship
class CargoShip extends Ship { 
    private int max40FtContainers; 
    private int max20FtContainers; 

    public CargoShip(String name, String shipClass, double tonnage, int capacity, int max40FtContainers, int max20FtContainers) {
        super(name, shipClass, tonnage, capacity); 
        this.max40FtContainers = max40FtContainers;
        this.max20FtContainers = max20FtContainers;
    }

    public String getCargoInfo() { 
        return String.format("40-foot Containers: %d pcs\n20-foot Containers: %d pcs",
            max40FtContainers, max20FtContainers);
    }
}

interface Container { 
    double getTotalWeight(); // Polymorphism
    double getTotalPrice(); // Polymorphism
}

// Implementation of 40-foot container
class FortyFtContainer implements Container {
    private String origin; 
    private String destination; 
    private int numContainers; 
    private double weightPerContainer; 
    private double pricePerContainer; 
    private double taxPerContainer; 

    public FortyFtContainer(String origin, String destination, int numContainers, double weightPerContainer, double pricePerContainer, double taxPerContainer) {
        this.origin = origin;
        this.destination = destination;
        this.numContainers = numContainers;
        this.weightPerContainer = weightPerContainer;
        this.pricePerContainer = pricePerContainer;
        this.taxPerContainer = taxPerContainer;
    }

    @Override
    public double getTotalWeight() { // Polymorphism
        return numContainers * weightPerContainer;
    }

    @Override
    public double getTotalPrice() { // Polymorphism
        return numContainers * (pricePerContainer + taxPerContainer);
    }

    public String getContainerInfo() { // Encapsulation
        return String.format("Origin of shipment: %s\nPort of destination and disembarkation of Container: %s\nNo. of pieces of containers for 40-foot containers: %d pcs\nWeight per container: %.2f kg\nTotal weight of all containers: %.2f kg\nPrice per container: %.2f pesos\nTax per container: %.2f pesos\nTotal price of the containers including tax: %.2f pesos",
                origin, destination, numContainers, weightPerContainer, getTotalWeight(), pricePerContainer, taxPerContainer, getTotalPrice());
    }
}

// Implementation of 20-foot container
class TwentyFtContainer implements Container { 
    private String origin; 
    private String destination; 
    private int numContainers; 
    private double weightPerContainer; 
    private double pricePerContainer; 
    private double taxPerContainer; 

    public TwentyFtContainer(String origin, String destination, int numContainers, double weightPerContainer, double pricePerContainer, double taxPerContainer) {
        this.origin = origin;
        this.destination = destination;
        this.numContainers = numContainers;
        this.weightPerContainer = weightPerContainer;
        this.pricePerContainer = pricePerContainer;
        this.taxPerContainer = taxPerContainer;
    }

    @Override
    public double getTotalWeight() { // Polymorphism
        return numContainers * weightPerContainer;
    }

    @Override
    public double getTotalPrice() { // Polymorphism
        return numContainers * (pricePerContainer + taxPerContainer);
    }

    public String getContainerInfo() { // Encapsulation
        return String.format("Origin of shipment: %s\nPort of destination and disembarkation of Container: %s\nNo. of pieces of containers for 20-foot containers: %d pcs\nWeight per container: %.2f kg\nTotal weight of all containers: %.2f kg\nPrice per container: %.2f pesos\nTax per container: %.2f pesos\nTotal price of the containers including tax: %.2f pesos",
                origin, destination, numContainers, weightPerContainer, getTotalWeight(), pricePerContainer, taxPerContainer, getTotalPrice());
    }
}

// Main class
public class CargoVessel {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        CargoShip ship = new CargoShip("HMM Algeciras", "Container ship", 232_311, 23_820, 2_000, 1_500);

        // 40-foot containers input
        System.out.println("=== 40-Foot Containers ===");
        String origin40 = "", destination40 = "";
        int num40FtContainers = 0;
        double weight40FtContainer = 0, price40FtContainer = 0, tax40FtContainer = 0;

        while (true) {
            try {
                System.out.print("Origin of shipment: ");
                origin40 = scanner.nextLine();
                if (!origin40.matches("^[a-zA-Z\\s]+$")) {
                    throw new IllegalArgumentException("Invalid input. Only alphabetic characters and spaces are allowed.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
            }
        }

        while (true) {
            try {
                System.out.print("Port of destination: ");
                destination40 = scanner.nextLine();
                if (!destination40.matches("^[a-zA-Z\\s]+$")) {
                    throw new IllegalArgumentException("Invalid input. Only alphabetic characters and spaces are allowed.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
            }
        }

        while (true) {
            try {
                System.out.print("Number of 40-foot containers: ");
                num40FtContainers = scanner.nextInt();
                if (num40FtContainers <= 0 || num40FtContainers > 2_000) {
                    throw new IllegalArgumentException("Invalid input. Number of 40-foot containers must be positive and not exceed 2,000.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
                scanner.nextLine(); 
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter numerical values where required.");
                scanner.nextLine();
            }
        }

        while (true) {
            try {
                System.out.print("Weight per 40-foot container (kg): ");
                weight40FtContainer = scanner.nextDouble();
                if (weight40FtContainer <= 0) {
                    throw new IllegalArgumentException("Invalid input. Weight per container must be positive.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter numerical values where required.");
                scanner.nextLine();
            }
        }

        while (true) {
            try {
                System.out.print("Price per 40-foot container: ");
                price40FtContainer = scanner.nextDouble();
                if (price40FtContainer < 0) {
                    throw new IllegalArgumentException("Invalid input. Price per container cannot be negative.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter numerical values where required.");
                scanner.nextLine();
            }
        }

        while (true) {
            try {
                System.out.print("Tax per 40-foot container: ");
                tax40FtContainer = scanner.nextDouble();
                if (tax40FtContainer < 0) {
                    throw new IllegalArgumentException("Invalid input. Tax per container cannot be negative.");
                }
                scanner.nextLine();  // consume the newline
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter numerical values where required.");
                scanner.nextLine();
            }
        }

        FortyFtContainer fortyFtContainer = new FortyFtContainer(origin40, destination40, num40FtContainers, weight40FtContainer, price40FtContainer, tax40FtContainer);

        // 20-foot containers input
        System.out.println("=== 20-Foot Containers ===");
        String origin20 = "", destination20 = "";
        int num20FtContainers = 0;
        double weight20FtContainer = 0, price20FtContainer = 0, tax20FtContainer = 0;

        while (true) {
            try {
                System.out.print("Origin of shipment: ");
                origin20 = scanner.nextLine();
                if (!origin20.matches("^[a-zA-Z\\s]+$")) {
                    throw new IllegalArgumentException("Invalid input. Only alphabetic characters and spaces are allowed.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
            }
        }

        while (true) {
            try {
                System.out.print("Port of destination: ");
                destination20 = scanner.nextLine();
                if (!destination20.matches("^[a-zA-Z\\s]+$")) {
                    throw new IllegalArgumentException("Invalid input. Only alphabetic characters and spaces are allowed.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
            }
        }

        while (true) {
            try {
                System.out.print("Number of 20-foot containers: ");
                num20FtContainers = scanner.nextInt();
                if (num20FtContainers <= 0 || num20FtContainers > 1_500) {
                    throw new IllegalArgumentException("Invalid input. Number of 20-foot containers must be positive and not exceed 1,500.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
                scanner.nextLine(); 
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter numerical values where required.");
                scanner.nextLine();
            }
        }

        while (true) {
            try {
                System.out.print("Weight per 20-foot container (kg): ");
                weight20FtContainer = scanner.nextDouble();
                if (weight20FtContainer <= 0) {
                    throw new IllegalArgumentException("Invalid input. Weight per container must be positive.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter numerical values where required.");
                scanner.nextLine();
            }
        }

        while (true) {
            try {
                System.out.print("Price per 20-foot container: ");
                price20FtContainer = scanner.nextDouble();
                if (price20FtContainer < 0) {
                    throw new IllegalArgumentException("Invalid input. Price per container cannot be negative.");
                }
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter numerical values where required.");
                scanner.nextLine();
            }
        }

        while (true) {
            try {
                System.out.print("Tax per 20-foot container: ");
                tax20FtContainer = scanner.nextDouble();
                if (tax20FtContainer < 0) {
                    throw new IllegalArgumentException("Invalid input. Tax per container cannot be negative.");
                }
                scanner.nextLine();  // consume the newline
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
                System.out.println("Please try again.");
                scanner.nextLine();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter numerical values where required.");
                scanner.nextLine();
            }
        }

        TwentyFtContainer twentyFtContainer = new TwentyFtContainer(origin20, destination20, num20FtContainers, weight20FtContainer, price20FtContainer, tax20FtContainer);

        // Display ship and container information
        System.out.println("\n=== Ships Information ===");
        System.out.println(ship.getShipInfo());
        System.out.println(ship.getCargoInfo());

        System.out.println("\n=== 40-Foot Containers ===");
        System.out.println(fortyFtContainer.getContainerInfo());

        System.out.println("\n=== 20-Foot Containers ===");
        System.out.println(twentyFtContainer.getContainerInfo());

        scanner.close();
    }
}

