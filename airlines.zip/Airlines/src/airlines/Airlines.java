/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package airlines;

// reference : https://flights.philippineairlines.com/en/
import java.util.Scanner;

interface FlightSchedule {
    int[] perWeekSchedule();
    int totalFlights();
}

class CalculateSchedules implements FlightSchedule {
    private int[] weeklyFlights;

    CalculateSchedules(int[] weeklyFlights) {
        this.weeklyFlights = weeklyFlights;
    }

    @Override
    public int[] perWeekSchedule() {
        return weeklyFlights;
    }

    @Override
    public int totalFlights() {
        int total = 0;
        for (int flights : weeklyFlights) {
            total += flights; // Summing up flights for each day
        }
        // No need to print total for 1st week here
        return total; // to get the sum of the flights
    }
}

public class Airlines {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String[] localFlights = {"Manila (MNL) to Cebu (CEB)", "Manila (MNL) to Tacloban (TAC)", "Davao City (DVO) to Manila (MNL)", "Manila (MNL) to Boracay (CATICLAN)"};

        String[] internationalFlights = {"Los Angeles (LAX) to Manila (MNL)", "Manila (MNL) to Sydney (SYD)", "San Francisco (SFO) to Manila (MNL)", "Riyadh (RUH) to Manila (MNL)"};

        String[] daysLabel = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

        Schedules s = new Schedules("Philippines", "Philippine Airlines (PAL)", localFlights, internationalFlights, daysLabel);

        System.out.println("Country: " + s.getName());
        System.out.println("Country: " + s.getAirlines());
        System.out.println("\t" + "Destination");
        System.out.println("Local Flights: ");
        for (String flight : s.getLocalFLights()) {
            System.out.println("\t" + "• " + flight);
        }

        System.out.println("International Flights: ");
        for (String flight : s.getInternationalFlights()) {
            System.out.println("\t" + "• " + flight);
        }

        System.out.println("Flights per Day:");
        int[] weeklyFlights = new int[7];
        for (int i = 0; i < daysLabel.length; i++) {
            boolean validInput = false;
            while (!validInput) {
                System.out.print("Enter total flights for " + daysLabel[i] + ": ");
                if (scan.hasNextInt()) {
                    weeklyFlights[i] = scan.nextInt();
                    validInput = true;
                } else {
                    System.out.println("Invalid input. Please enter a valid number.");
                    scan.next(); // Clear the invalid input from the scanner
                }
            }
        }

        System.out.println("\nFlights per Month:");

        CalculateSchedules cs = new CalculateSchedules(weeklyFlights);
        int totalFlightsFirstWeek = cs.totalFlights(); // Calculate total flights for the first week

        // Print total flights for the first week
        System.out.println("1st Week: " + totalFlightsFirstWeek);

        // Add flights from the second week to the fourth week
        int totalFlightsMonth = totalFlightsFirstWeek;
        for (int i = 2; i <= 4; i++) {
            boolean validInput = false;
            while (!validInput) {
                System.out.print(i + "nd week: ");
                if (scan.hasNextInt()) {
                    int flights = scan.nextInt();
                    totalFlightsMonth += flights;
                    validInput = true;
                } else {
                    System.out.println("Invalid input. Please enter a valid number.");
                    scan.next(); // Clear the invalid input from the scanner
                }
            }
        }
        System.out.println("\nTotal Number of Flights Schedule: " + totalFlightsMonth + " Flights.");
    }
}
       

