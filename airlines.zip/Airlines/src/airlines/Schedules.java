/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airlines;

import java.util.Arrays;


//subclass
public class Schedules extends Philippines{
    private String [] localFlights;
    private String [] internationalFlights;
    private String [] daysLabel;
    public Schedules(String countryName, String airlinesName, String[] localFlights, String[] internationalFlights, String[] daysLabel) {
        super(countryName, airlinesName);
        this.localFlights = Arrays.copyOf(localFlights, localFlights.length);
        this.internationalFlights = Arrays.copyOf(internationalFlights, internationalFlights.length);
        this.daysLabel = Arrays.copyOf(daysLabel, daysLabel.length);
        
    }
    public String [] getLocalFLights(){
        return Arrays.copyOf(localFlights, localFlights.length);
    }
    public String [] getInternationalFlights(){
        return Arrays.copyOf(internationalFlights, internationalFlights.length);
    }
    public String [] getDaysLabel(){
        return Arrays.copyOf(daysLabel, daysLabel.length);
    }
    
}
