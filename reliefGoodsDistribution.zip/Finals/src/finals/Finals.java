/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finals;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.List;

public class Finals {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginFrame::new);
    }
}

// Login Frame
class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JButton loginButton;
     private LoginButtonListener loginButtonListener = new LoginButtonListener();
    
    public LoginFrame() {
        setTitle("Login");

        // Set default frame size and close operation
        setSize(800, 600); // Initial size, can be any size that suits your layout
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Load the original background image
        ImageIcon originalImage = new ImageIcon("C:\\LoginPage.png");

        // Create JLabel with the initial resized image based on frame dimensions
        Image initialResizedImage = originalImage.getImage().getScaledInstance(getWidth(), getHeight(), Image.SCALE_SMOOTH);
        JLabel backgroundLabel = new JLabel(new ImageIcon(initialResizedImage));
        backgroundLabel.setLayout(new GridBagLayout());

        // Title label
        JLabel titleLabel = new JLabel("Login", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Verdana", Font.BOLD, 36));
        titleLabel.setForeground(Color.BLACK);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        backgroundLabel.add(titleLabel, gbc);

        // Username label
        JLabel usernameLabel = new JLabel("Admin:");
        usernameLabel.setFont(new Font("Verdana", Font.BOLD, 24));
        usernameLabel.setForeground(Color.BLACK);
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        backgroundLabel.add(usernameLabel, gbc);

        // Username text field
        usernameField = new JTextField();
        usernameField.setPreferredSize(new Dimension(300, 40));
        usernameField.setFont(new Font("Verdana", Font.PLAIN, 24));
        gbc.gridx = 1;
        backgroundLabel.add(usernameField, gbc);

        // Login button
        loginButton = new JButton("Login");
        loginButton.setBackground(Color.BLUE);
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Verdana", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 0;
        backgroundLabel.add(loginButton, gbc);

        // Add the action listener
        loginButton.addActionListener(new LoginButtonListener());
        
        
        
         // Add the key listener for the Enter key
        usernameField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Trigger the login action
                    loginButtonListener.actionPerformed(new ActionEvent(usernameField, ActionEvent.ACTION_PERFORMED, null));
                }
            }
        });

        // Set background label as content pane
        setContentPane(backgroundLabel);
        setExtendedState(JFrame.MAXIMIZED_BOTH);  // Maximize the frame

        // Add a ComponentListener to resize the background image when frame is resized
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int newWidth = getWidth();
                int newHeight = getHeight();

                // Resize the image based on new frame dimensions
                Image resizedImage = originalImage.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
                backgroundLabel.setIcon(new ImageIcon(resizedImage));
            }
        });

        setVisible(true);
    }

     private class LoginButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String role = usernameField.getText().trim().toLowerCase();
            if (role.equals("brgy captain") || role.equals("brgy kagawad") || role.equals("BRGY CAPTAIN") || role.equals("BRGY KAGAWAD")) {
                dispose(); 
                new ReliefGoodsSystem(); 
            } else {
                JOptionPane.showMessageDialog(LoginFrame.this, "Invalid role. Please enter 'brgy captain' or 'brgy kagawad'.");
            }
        }
    }

}
// Relief Goods System Frame
class ReliefGoodsSystem {
    enum CitizenType { SENIOR, CHILD, REGULAR }

    static class Citizen {
        private String name;
        private String address;
        private String contactNumber;
        private int familyMembers;
        private CitizenType type;
        private String disasterType;
        private String id;

        public Citizen(String name, String address, String contactNumber, int familyMembers, CitizenType type, String disasterType, String id) {
            this.name = name;
            this.address = address;
            this.contactNumber = contactNumber;
            this.familyMembers = familyMembers;
            this.type = type;
            this.disasterType = disasterType;
            this.id = id;
        }

        @Override
        public String toString() {
            return "ID: " + id + "\nName: " + name + "\nAddress: " + address +
                   "\nContact: " + contactNumber + "\nFamily Members: " + familyMembers +
                   "\nDisaster Type: " + disasterType + "\nCitizen Type: " + type;
        }

        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }
    }
    private Map<String, ArrayList<Citizen>> disasterCitizensMap = new HashMap<>();
    private JFrame frame;
    private JTextField nameField, addressField, contactField, familyMembersField;
    private JComboBox<String> citizenTypeComboBox, DisasterTypesComboBox;
    private JButton addsButton, addButton;
    private JTextArea queueDisplay;


    public ReliefGoodsSystem() {
        // Create the frame
        frame = new JFrame("Relief Goods Distribution");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set frame to full screen size
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setSize(screenSize.width, screenSize.height);

        // Load the background image
        ImageIcon secondImage = new ImageIcon("C:\\registrationForm.png");

        // Create a scaled image based on frame dimensions
        Image initialResizedImage = secondImage.getImage().getScaledInstance(screenSize.width, screenSize.height, Image.SCALE_SMOOTH);

        // Create a panel that overrides the paintComponent method to draw the background
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw the background image, rescaled to fit the panel
                if (initialResizedImage != null) {
                    g.drawImage(initialResizedImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        backgroundPanel.setLayout(new GridBagLayout()); // Set layout on the background panel

        // Panel for inputs (to hold form fields)
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridBagLayout());
        inputPanel.setOpaque(false); // Make this panel transparent so the background is visible
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Add padding around components
        gbc.fill = GridBagConstraints.HORIZONTAL; // Make components fill horizontally

        JLabel titleLabel = new JLabel("Relief Goods Distribution", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Verdana", Font.BOLD, 24));
        titleLabel.setForeground(Color.BLACK);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        inputPanel.add(titleLabel, gbc);

        JLabel DisasterType = new JLabel("Disaster Type:");
        DisasterType.setFont(new Font("Verdana", Font.BOLD, 16));
        DisasterType.setForeground(Color.BLACK);
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        inputPanel.add(DisasterType, gbc);

        String[] DisasterTypes = {"Flood", "Landslide", "Tsunami", "Fire", "Earthquake"};
        DisasterTypesComboBox = new JComboBox<>(DisasterTypes);
        DisasterTypesComboBox.setFont(new Font("Verdana", Font.PLAIN, 16));
        DisasterTypesComboBox.setPreferredSize(new Dimension(300, 40));
        DisasterTypesComboBox.setBackground(Color.WHITE);
        DisasterTypesComboBox.setForeground(Color.black);
        DisasterTypesComboBox.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 1;
        inputPanel.add(DisasterTypesComboBox, gbc);

        JLabel Name = new JLabel("Name: ");
        Name.setFont(new Font("Verdana", Font.BOLD, 16));
        Name.setForeground(Color.BLACK);
        gbc.gridy = 2; // Move to the next row
        gbc.gridx = 0; // First column
        inputPanel.add(Name, gbc);

        nameField = new JTextField();
        nameField.setPreferredSize(new Dimension(300, 40));
        nameField.setFont(new Font("Verdana", Font.PLAIN, 19));
        nameField.setBackground(Color.WHITE);
        nameField.setForeground(Color.black);
        nameField.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        gbc.gridx = 1; // Second column for text field
        inputPanel.add(nameField, gbc);

        // Additional fields setup here as in your original code...
          // Citizen Type
        JLabel citizenTypeLabel = new JLabel("Select Citizen Type: ");
        citizenTypeLabel.setFont(new Font("Verdana", Font.BOLD, 16));
        citizenTypeLabel.setForeground(Color.BLACK);
        gbc.gridy = 3;
        gbc.gridx = 0;
        inputPanel.add(citizenTypeLabel, gbc);

        String[] citizenTypes = {"Senior - 60 years old & above", "Child - 7 years old & below", "Regular Citizens"};
        citizenTypeComboBox = new JComboBox<>(citizenTypes);
        citizenTypeComboBox.setFont(new Font("Verdana", Font.PLAIN,16));
        citizenTypeComboBox.setPreferredSize(new Dimension(300, 50));
        citizenTypeComboBox.setBackground(Color.WHITE);
        citizenTypeComboBox.setForeground(Color.BLACK);
        citizenTypeComboBox.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 1;
        inputPanel.add(citizenTypeComboBox, gbc);
        
        // Address
        JLabel addressLabel = new JLabel("Address: ");
        addressLabel.setFont(new Font("Verdana", Font.BOLD, 16));
        addressLabel.setForeground(Color.BLACK);
        gbc.gridy = 4;
        gbc.gridx = 0;
        inputPanel.add(addressLabel, gbc);

        addressField = new JTextField();
        addressField.setPreferredSize(new Dimension(300, 40));
        addressField.setFont(new Font("Verdana", Font.PLAIN,19));
        addressField.setBackground(Color.WHITE);
        addressField.setForeground(Color.black);
        addressField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 1;
        inputPanel.add(addressField, gbc);

        // Contact Number
        JLabel contactLabel = new JLabel("Contact No.: ");
        contactLabel.setFont(new Font("Verdana", Font.BOLD, 16));
        contactLabel.setForeground(Color.BLACK);
        gbc.gridy = 5;
        gbc.gridx = 0;
        inputPanel.add(contactLabel, gbc);

        contactField = new JTextField();
        contactField.setPreferredSize(new Dimension(300, 40));
        contactField.setFont(new Font("Verdana", Font.PLAIN,19));
        contactField.setBackground(Color.WHITE);
        contactField.setForeground(Color.black);
        contactField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 1;
        inputPanel.add(contactField, gbc);

        // Family Members
        JLabel familyMembersLabel = new JLabel("No. of Family Members: ");
        familyMembersLabel.setFont(new Font("Verdana", Font.BOLD, 16));
        familyMembersLabel.setForeground(Color.BLACK);
        gbc.gridy = 6;
        gbc.gridx = 0;
        inputPanel.add(familyMembersLabel, gbc);

        familyMembersField = new JTextField();
        familyMembersField.setPreferredSize(new Dimension(300, 40));
        familyMembersField.setFont(new Font("Verdana", Font.PLAIN,19));
        familyMembersField.setBackground(Color.WHITE);
        familyMembersField.setForeground(Color.black);
        familyMembersField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 1;
        inputPanel.add(familyMembersField, gbc);

        addsButton = new JButton("Add Information");
        addsButton.addActionListener(e -> addCitizen());
        addsButton.setFont(new Font("Verdana", Font.BOLD, 14));
        addsButton.setBackground(Color.BLUE);
        addsButton.setForeground(Color.WHITE);
        addsButton.setFocusPainted(false);
        gbc.gridy = 7; // Move to the next row
        gbc.gridwidth = 2; // Span both columns
        inputPanel.add(addsButton, gbc);

        JButton searchButton = new JButton("Check Citizens");
        searchButton.setFont(new Font("Verdana", Font.BOLD, 14));
        searchButton.setBackground(Color.BLUE);
        searchButton.setForeground(Color.WHITE);
        searchButton.setFocusPainted(false);
        searchButton.addActionListener(e -> new SearchFrame(disasterCitizensMap)); // Open SearchFrame
        gbc.gridy = 8; // Move to the next row
        inputPanel.add(searchButton, gbc);

        
        // Add inputPanel to the backgroundPanel
        backgroundPanel.add(inputPanel, gbc); // Add inputPanel in the background layout

        // Set the content pane of the frame to the background panel
        frame.setContentPane(backgroundPanel);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximize frame to fill the screen
        frame.setVisible(true);
    }


     private void addCitizen() {
        String name = nameField.getText().trim();
        String address = addressField.getText().trim();
        String contact = contactField.getText().trim();
        String familyMembers = familyMembersField.getText().trim();
        String disasterType = (String) DisasterTypesComboBox.getSelectedItem();
        CitizenType citizenType = CitizenType.REGULAR;

        if (citizenTypeComboBox.getSelectedItem().toString().contains("Senior")) {
            citizenType = CitizenType.SENIOR;
        } else if (citizenTypeComboBox.getSelectedItem().toString().contains("Child")) {
            citizenType = CitizenType.CHILD;
        }

        if (name.isEmpty() || address.isEmpty() || contact.isEmpty() || familyMembers.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill in all fields.");
            return;
        }
        
        // Validate contact number format
        if (!contact.matches("^09\\d{9}$")) {
            JOptionPane.showMessageDialog(frame, "Invalid contact number format. Please enter an 11-digit number starting with '09'.");
            return;
        }
        
        try {
            int numFamilyMembers = Integer.parseInt(familyMembers);
            String uniqueID = disasterType.charAt(0) + UUID.randomUUID().toString().substring(0, 8);
            Citizen citizen = new Citizen(name, address, contact, numFamilyMembers, citizenType, disasterType, uniqueID);
            
            // Add citizen to the map
            disasterCitizensMap.computeIfAbsent(disasterType, k -> new ArrayList<>()).add(citizen);
            JOptionPane.showMessageDialog(frame, "Citizen added successfully!");

            // Clear input fields
            nameField.setText("");
            addressField.setText("");
            contactField.setText("");
            familyMembersField.setText("");
            citizenTypeComboBox.setSelectedIndex(0); // Reset to the first item
            DisasterTypesComboBox.setSelectedIndex(0); // Reset to the first item
            nameField.requestFocusInWindow(); // Set focus back to nameField

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Number of family members must be a valid integer.");
        }
    }

   public class SearchFrame extends JFrame {
    private JComboBox<String> disasterTypeComboBox;
    private JTextField nameSearchField;
    private JButton searchButton, nameSearchButton, backButton, deleteButton;
    private JTable resultsTable;
    private DefaultTableModel tableModel;
    private Map<String, ArrayList<Citizen>> disasterCitizensMap;

    public SearchFrame(Map<String, ArrayList<Citizen>> disasterCitizensMap) {
        this.disasterCitizensMap = disasterCitizensMap;
        
        setTitle("Citizen Search");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        setupBackground();
        setupSearchComponents();
        setupTable();
        setupDeleteButton(); // Set up the delete button

        searchByDisasterType("All Citizens", disasterCitizensMap); // Show all on load
        setVisible(true);
    }

    private void setupBackground() {
        // Set up background and layout
        ImageIcon secondImage = new ImageIcon("C:\\tableFrame.png");
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Image initialResizedImage = secondImage.getImage().getScaledInstance(screenSize.width, screenSize.height, Image.SCALE_SMOOTH);

        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (initialResizedImage != null) {
                    g.drawImage(initialResizedImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        backgroundPanel.setLayout(null);
        setContentPane(backgroundPanel);
    }

    private void setupSearchComponents() {
        // Set up disaster type combo box, name search field, and search buttons
        String[] disasterTypes = {"All Citizens", "Flood", "Landslide", "Tsunami", "Fire", "Earthquake"};
        disasterTypeComboBox = new JComboBox<>(disasterTypes);
        searchButton = new JButton("Search");
        nameSearchField = new JTextField(20);
        nameSearchButton = new JButton("Search");
        backButton = new JButton("Back");

        JLabel searchLabel = new JLabel("Select Disaster Type:");
        JLabel searchNameLabel = new JLabel("Select Name:");
        
        // Set bounds and add components
        searchLabel.setBounds(242, 30, 150, 30);
        searchNameLabel.setBounds(242, 80, 150, 30);
        disasterTypeComboBox.setBounds(400, 30, 150, 30);
        searchButton.setBounds(560, 30, 90, 30);
        nameSearchField.setBounds(400, 80, 230, 30);
        nameSearchButton.setBounds(640, 80, 90, 30);
        backButton.setBounds(980, 30, 90, 30);

        addActionListeners();
        getContentPane().add(searchLabel);
        getContentPane().add(searchNameLabel);
        getContentPane().add(disasterTypeComboBox);
        getContentPane().add(searchButton);
        getContentPane().add(nameSearchField);
        getContentPane().add(nameSearchButton);
        getContentPane().add(backButton);
    }

    private void setupTable() {
        // Set up table with additional columns for detailed citizen info
        String[] columnNames = {"ID", "Name", "Citizen Type", "Address", "Contact No.", "No. of Family Members"};
        tableModel = new DefaultTableModel(columnNames, 0);
        resultsTable = new JTable(tableModel);
        
        JScrollPane scrollPane = new JScrollPane(resultsTable);
        scrollPane.setBounds(230, 130, 850, 500);
        getContentPane().add(scrollPane);
    }

    private void setupDeleteButton() {
        // Add a Delete Button
        deleteButton = new JButton("Delete");
        deleteButton.setBounds(740, 80, 90, 30);
        deleteButton.setFont(new Font("Verdana", Font.BOLD, 12));
        deleteButton.setFocusPainted(false);
        

        deleteButton.addActionListener(e -> deleteSelectedCitizen());
        getContentPane().add(deleteButton);
    }

    private void addActionListeners() {
        searchButton.addActionListener(e -> searchByDisasterType((String) disasterTypeComboBox.getSelectedItem(), disasterCitizensMap));
        nameSearchButton.addActionListener(e -> searchByName(nameSearchField.getText().trim()));
        backButton.addActionListener(e -> dispose());
    }

    private void deleteSelectedCitizen() {
        int selectedRow = resultsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a citizen to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this citizen?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            String citizenID = (String) tableModel.getValueAt(selectedRow, 0);

            // Find and remove the citizen from disasterCitizensMap
            disasterCitizensMap.forEach((disasterType, citizenList) -> citizenList.removeIf(citizen -> citizen.getId().equals(citizenID)));

            // Remove the row from the table model
            tableModel.removeRow(selectedRow);
            JOptionPane.showMessageDialog(this, "Citizen deleted successfully.");
        }
    }

    private void searchByDisasterType(String selectedDisasterType, Map<String, ArrayList<Citizen>> disasterCitizensMap) {
        tableModel.setRowCount(0); // Clear the table
        List<Citizen> citizens = new ArrayList<>();
        
        if ("All Citizens".equals(selectedDisasterType)) {
            disasterCitizensMap.values().forEach(citizens::addAll);
        } else {
            citizens.addAll(disasterCitizensMap.getOrDefault(selectedDisasterType, new ArrayList<>()));
        }

        if (citizens.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No citizens found.");
        } else {
            citizens.forEach(citizen -> tableModel.addRow(new Object[]{
                citizen.getId(),
                citizen.getName(),
                citizen.type,
                citizen.address,
                citizen.contactNumber,
                citizen.familyMembers
            }));
        }
    }

    private void searchByName(String name) {
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a name to search.");
            return;
        }

        boolean found = false;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String citizenInfo = (String) tableModel.getValueAt(i, 1);
            if (citizenInfo.toLowerCase().contains(name.toLowerCase())) {
                resultsTable.setRowSelectionInterval(i, i);
                resultsTable.scrollRectToVisible(resultsTable.getCellRect(i, 0, true));
                found = true;
                break;
            }
        }

        if (!found) {
            JOptionPane.showMessageDialog(this, "Citizen not found.");
        }
    }
}
}