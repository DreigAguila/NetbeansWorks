package realtictactoe;
import java.util.Scanner;
public class RealTicTacToe {
    public static void main(String[] args) { 
            char[] gameboard = {' ', '1', '2', '3', '4', '5', '6', '7', '8', '9'}; // A 1D array to give the gameboard the variables that is needed 

        while (true) { // Start of the Main conditions with their Methods (Gameboard, Draw, Win, Move etc.). 
            board(gameboard); // To show the gameboard
            Scanner scanner = new Scanner(System.in); // Initialize Scanner for input of user

            System.out.print("Player 1, Choose your move (0-8): "); // First question, asking the first player where to put their piece
            int input1 = getPlayerMove(scanner, gameboard); 
            gameboard[input1] = 'X';
            board(gameboard);

            if (checkWin(gameboard, 'X')) {
                System.out.println("Player 1 wins!");
                break;
            } else if (isBoardFull(gameboard)) {
                System.out.println("It's a tie!");
                break;
            }

            System.out.print("Player 2, Choose your move (0-8): ");
            int input2 = getPlayerMove(scanner, gameboard);
            gameboard[input2] = 'O';

            if (checkWin(gameboard, 'O')) {
                System.out.println("Player 2 wins!");
                break;
            } else if (isBoardFull(gameboard)) {
                System.out.println("It's a tie!");
                break;
            }
        }
    }

    private static int getPlayerMove(Scanner scanner, char[] gameboard) {
        int move;
        while (true) {
            if (scanner.hasNextInt()) {
                move = scanner.nextInt();
                if (move >= 1 && move <= 9 && gameboard[move] >= '1' && gameboard[move] <= '9') {
                    break;
                } else {
                    System.out.println("Invalid move. Please choose a valid move (0-8): ");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Consume the invalid input to avoid an infinite loop
            }
        }
        return move;
    }

    private static void board(char[] gameboard) {
        System.out.println(" " + gameboard[1] + " | " + gameboard[2] + " | " + gameboard[3]);
        System.out.println("-----------");
        System.out.println(" " + gameboard[4] + " | " + gameboard[5] + " | " + gameboard[6]);
        System.out.println("-----------");
        System.out.println(" " + gameboard[7] + " | " + gameboard[8] + " | " + gameboard[9]);
    }

    private static boolean checkWin(char[] board, char player) {
        // Check rows, columns, and diagonals for a win
        return (board[1] == player && board[2] == player && board[3]== player) ||
               (board[4] == player && board[5] == player && board[6] == player) ||
               (board[7] == player && board[8] == player && board[9] == player) ||
                // row
               (board[1] == player && board[4] == player && board[7] == player) ||
               (board[2] == player && board[5] == player && board[8] == player) ||
               (board[3] == player && board[6] == player && board[9] == player) ||
                //column
               (board[1] == player && board[5] == player && board[9] == player) ||
               (board[3] == player && board[5] == player && board[7] == player);
               // diagonal
    }

    private static boolean isBoardFull(char[] board) {
        // Check if the board is full (no more empty spaces)
        for (char cell : board) {
            if (cell >= '1' && cell <= '9') {
                return false;
            }
        }
        return true;
    }
}