/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package currencyconverter;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;

public class CurrencyConverter extends javax.swing.JFrame{
    
    CurrencyConverter(){
        JFrame frame = new JFrame();
        
        //the labels
        JLabel pesoConverterLabel = new JLabel ("Peso Converter");
        pesoConverterLabel.setBounds(10,3,150,20);
        frame.add(pesoConverterLabel);
                
        JLabel php = new JLabel("PHP: ");
        php.setBounds(20,40,100,40);
        frame.add(php);
        
        JLabel exRate = new JLabel("Exchange Rates");
        exRate.setBounds(240,0, 100, 40);
        frame.add(exRate);
        
        JLabel lblUsd = new JLabel("56.38 PHP = 1 USD");
        lblUsd.setBounds(240, 15, 120, 40);
        frame.add(lblUsd);
        
        JLabel lblEuro = new JLabel("61.08 PHP = 1 EURO");
        lblEuro.setBounds(240, 30, 120, 40);
        frame.add(lblEuro);
        
        JLabel lblFranc = new JLabel("65.43 = 1 FRANC");
        lblFranc.setBounds(240, 45, 120, 40);
        frame.add(lblFranc);
                
        JLabel programmer = new JLabel("Programmed by: Dreig");
        programmer.setBounds(100, 210, 200, 30);
        frame.add(programmer);
        
        JLabel lblconverter = new JLabel("");
        lblconverter.setBounds(90,160,150,40);
        frame.add(lblconverter);
        
        JLabel currencyLabel = new JLabel("Result: ");
        currencyLabel.setBounds(20, 160, 120, 40);
        frame.add(currencyLabel);
        
        // textfields
        JTextField txtPHP = new JTextField("");
        txtPHP.setBounds(60, 40, 150, 40);
        frame.add(txtPHP);
        
        JTextField txtConverter = new JTextField("");
        txtConverter.setBounds(80,160,150,40);
        frame.add(txtConverter);
        
        
        //here are the buttons
        JButton btn = new JButton("USD");
        btn.setBounds(40, 100, 90, 40);
        
        btn.addActionListener (new ActionListener(){
           
        @Override
        public void actionPerformed(ActionEvent e) {
        double peso = Double.parseDouble(txtPHP.getText());
        double usdConverter = peso / 56.38;
        lblconverter.setText(String.format("%.2f", usdConverter));
        currencyLabel.setText("USD: ");
    }
       });
        JButton btn1 = new JButton("EURO");
        btn1.setBounds(140, 100, 90, 40);
        
        btn1.addActionListener (new ActionListener(){
           
        @Override
        public void actionPerformed(ActionEvent e) {
        double peso = Double.parseDouble(txtPHP.getText());
        double euroConverter = peso / 61.08;
        lblconverter.setText(String.format("%.2f", euroConverter));
        currencyLabel.setText("EURO: ");
    }
       });
        
        JButton btn2 = new JButton("FRANCS");
        btn2.setBounds(240,100, 90, 40);
        
        btn2.addActionListener (new ActionListener(){
           
        @Override
        public void actionPerformed(ActionEvent e) {
        double peso = Double.parseDouble(txtPHP.getText());
        double francConverter = peso / 65.43;
        lblconverter.setText(String.format("%.2f", francConverter));
        currencyLabel.setText("FRANC: ");
    }
       });
        
        frame.add(btn);
        frame.add(btn1);
        frame.add(btn2);
        
        
        php.setFont(new Font("Verdana", Font.BOLD, 13));
        currencyLabel.setFont(new Font("Verdana", Font.BOLD, 13));
        pesoConverterLabel.setFont(new Font("Verdana", Font.BOLD, 15));
        programmer.setFont(new Font("Verdana", Font.BOLD, 13));
        programmer.setForeground(Color.blue);
        
        frame.getContentPane().setBackground(Color.lightGray);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400,300);
        frame.setLayout(null);
        frame.setVisible(true);
        
    }
    public static void main(String[] args) {
        new CurrencyConverter();
        
        
    }
    
}
