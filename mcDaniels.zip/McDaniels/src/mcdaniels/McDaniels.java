/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mcdaniels;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

class Customer {
    private DoubleEndedLinkedList<FoodItem> order;
    private int orderNumber;
    private String customerName;

    public Customer(String customerName1) {
        this.order = new DoubleEndedLinkedList<>();
        this.customerName = customerName;
    }
    
    // Get the customer's name
    public String getCustomerName() {
        return customerName;
    }

    // Set the customer's name
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
        
    }
    public void addFoodItem(FoodItem item) {
        order.addLast(item);
    }

    public void removeFoodItem(FoodItem item) {
        Node<FoodItem> current = order.getHead();
        while (current != null) {
            if (current.getData().equals(item)) {
                if (current.getPrev() != null) {
                    current.getPrev().setNext(current.getNext());
                } else {
                    order.removeFirst(); // Remove head if it's the first node
                }
                if (current.getNext() != null) {
                    current.getNext().setPrev(current.getPrev());
                } else {
                    order.removeLast(); // Remove tail if it's the last node
                }
                return;
            }
            current = current.getNext();
            
        }
        
    }

    public List<FoodItem> getOrder() {
        List<FoodItem> items = new ArrayList<>();
        Node<FoodItem> current = order.getHead();
        while (current != null) {
            items.add(current.getData());
            current = current.getNext();
        }
        return items;
    }

    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getOrderNumber() {
        return orderNumber;
    }
}
class FoodItem {
    private String name;
    private double price;

    public FoodItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return name + " - $" + price;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        FoodItem foodItem = (FoodItem) obj;
        return Double.compare(foodItem.price, price) == 0 &&
               name.equals(foodItem.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, price);
    }
}

class Node<T> {
    private T data;
    private Node<T> next;
    private Node<T> prev;

    public Node(T data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public Node<T> getNext() {
        return next;
    }

    public void setNext(Node<T> next) {
        this.next = next;
    }

    public Node<T> getPrev() {
        return prev;
    }

    public void setPrev(Node<T> prev) {
        this.prev = prev;
    }
}
class DoubleEndedLinkedList<T> {
    private Node<T> head;
    private Node<T> tail;

    public DoubleEndedLinkedList() {
        this.head = null;
        this.tail = null;
    }

    public void addFirst(T data) {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = tail = newNode;
        } else {
            newNode.setNext(head);
            head.setPrev(newNode);
            head = newNode;
        }
    }

    public void addLast(T data) {
        Node<T> newNode = new Node<>(data);
        if (tail == null) {
            head = tail = newNode;
        } else {
            newNode.setPrev(tail);
            tail.setNext(newNode);
            tail = newNode;
        }
    }

    public T removeFirst() {
        if (head == null) return null;
        T data = head.getData();
        head = head.getNext();
        if (head == null) {
            tail = null;
        } else {
            head.setPrev(null);
        }
        return data;
    }

    public T removeLast() {
        if (tail == null) return null;
        T data = tail.getData();
        tail = tail.getPrev();
        if (tail == null) {
            head = null;
        } else {
            tail.setNext(null);
        }
        return data;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public Node<T> getHead() {
        return head;
    }
}
public class McDaniels extends JFrame {
    private DoubleEndedLinkedList orderQueue;
    private JTextField nameField;
    private Customer currentCustomer;
    
    private FoodItem selectedItem;
    
    JFrame Start;
    JFrame greetingsPage;
    JFrame menuPage;
    JFrame MealsMenu;
    JFrame DessertsMenu;
    JFrame DrinksMenu;
    JFrame viewOrderFrame;
    JFrame ProceedToCheckOutFrame;
    JFrame CheckOutFrameCash;
    JFrame CheckOutFrameCard;
   
    
    public McDaniels() {
        orderQueue = new DoubleEndedLinkedList();
        
      
    }
    public void coverPage() {
        Start = new JFrame("McDaniels");

        // Load the background image
        ImageIcon backgroundIcon = new ImageIcon("C:\\McDaniels.png");
        Image backgroundImage = backgroundIcon.getImage();

        // Debug: Check if the image is loading correctly
        if (backgroundImage == null || backgroundImage.getWidth(null) == -1 || backgroundImage.getHeight(null) == -1) {
            System.out.println("Image failed to load.");
        } else {
            System.out.println("Image loaded successfully.");
        }
        
        
        // Custom contentPane with background image
        JPanel coverContentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };

        coverContentPane.setLayout(null); // Set layout to null to use absolute positioning
        
        // Text Field for Name Input
        nameField = new JTextField("Enter your name");
        nameField.setBounds(130, 260, 240, 50);
        nameField.setFont(new Font("Arial", Font.PLAIN, 20));
        nameField.setForeground(Color.GRAY);
        nameField.setBackground(Color.WHITE);
        nameField.setBorder(BorderFactory.createLineBorder(new Color(211, 211, 211))); // Light Gray Border
        nameField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (nameField.getText().equals("Enter your name")) {
                    nameField.setText("");
                    nameField.setForeground(new Color(77, 38, 0)); // Deep Brown when typing
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (nameField.getText().isEmpty()) {
                    nameField.setForeground(Color.GRAY);
                    nameField.setText("Enter your name");
                }
            }
        });
        coverContentPane.add(nameField);
        
        //proceedButton to start the app
        JButton proceedButton = new JButton("Proceed");
        proceedButton.setBounds(185, 345, 140, 40);
        proceedButton.setFont(new Font("Arial", Font.BOLD, 20));
        proceedButton.setForeground(new Color(0, 0, 0)); // Black text for contrast
        proceedButton.setFocusPainted(false);
        proceedButton.setBorder(BorderFactory.createLineBorder(new Color(211, 211, 211), 2)); // Light Gray Border
        proceedButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        proceedButton.setContentAreaFilled(true);
        proceedButton.setOpaque(true);
        coverContentPane.add(proceedButton);

        // Add ActionListener to the Start Button
        proceedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the customer's name
                String customerName = nameField.getText().trim();
                
                // Regular expression to check for exactly 8 words (words separated by spaces)
                String regex = "^[a-zA-Z]{1,8}$";
                
                if (customerName.isEmpty() || customerName.equals("Enter your name")) {
                    JOptionPane.showMessageDialog(Start, "Please enter your name.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    
                } else if (!customerName.matches(regex)){
                    JOptionPane.showMessageDialog(Start, "Name must consist of 1 to 8 letters only.", "Input Error", JOptionPane.ERROR_MESSAGE);    
                }
                else {
                    // Close the Start frame and open the MenuPage frame
                    Start.setVisible(false);
                    System.out.println("Show customer name: " + customerName);
                    greetingsPage(customerName);
                }
            }
        });
        
        Start.setContentPane(coverContentPane);
        Start.setSize(520, 520);
        Start.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Start.setLocationRelativeTo(null); // Center the frame
        Start.setVisible(true);
    }
    
    public void greetingsPage(String customerName) {
        currentCustomer = new Customer(customerName);
        orderQueue.addLast(currentCustomer);
        
        greetingsPage = new JFrame("Greetings");
        
        ImageIcon menuPageBackgroundIcon = new ImageIcon("C:\\greetingsPage.png");
        Image menuPageImage = menuPageBackgroundIcon.getImage();
        // Set a white background
        // Debug: Check if the image is loading correctly
        if (menuPageImage.getWidth(null) == -1 || menuPageImage.getHeight(null) == -1) {
            System.out.println("Image failed to load.");
        } else {
            System.out.println("Image loaded successfully.");
        }

        // Custom contentPane with background image
        JPanel greetContentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(menuPageImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        greetingsPage.setContentPane(greetContentPane);
        greetContentPane.setLayout(null);
        
        // Determine the appropriate greeting based on the current time
        LocalTime currentTime = LocalTime.now();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");
        String formattedTime = currentTime.format(timeFormatter);

        String greeting;
        if (currentTime.isBefore(LocalTime.NOON)) {
            greeting = "Good Morning, " + customerName + "!";
        } else if (currentTime.isBefore(LocalTime.of(18, 0))) {
            greeting = "Good Afternoon, " + customerName + "!";
        } else {
            greeting = "Good Evening, " + customerName + "!";
        }
       
        //greetings
        JLabel greetingLabel = new JLabel("<html><div style='text-align: center;'>" + greeting + "</div></html>");
        greetingLabel.setBounds(15, 35, 400, 50);
        greetingLabel.setFont(new Font("Arial", Font.BOLD, 25)); // Adjust font size if necessary
        greetingLabel.setForeground(Color.WHITE); // White text color
        greetContentPane.add(greetingLabel);
       
        // Current Time Label
        JLabel timeLabel = new JLabel(formattedTime);
        timeLabel.setBounds(285, 35, 180, 50);
        timeLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        timeLabel.setForeground(Color.WHITE);
        timeLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        greetContentPane.add(timeLabel);
        
        // Return Button to go back to the cover page and remove the customer from the queue
        JButton returnButton = new JButton("<");
        returnButton.setBounds(20, 430, 60, 30);
        returnButton.setFont(new Font("Arial", Font.BOLD, 20));
        returnButton.setForeground(new Color(0, 0, 0));
        returnButton.setFocusPainted(false);
        returnButton.setBorder(BorderFactory.createLineBorder(new Color(211, 211, 211), 2));
        returnButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        returnButton.setContentAreaFilled(true);
        returnButton.setOpaque(true);
        greetContentPane.add(returnButton);
        
        returnButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Remove the current customer from the queue
            orderQueue.removeFirst();
            System.out.println("show the remove name: " + customerName);
            // Clear the name field in the cover page
            nameField.setText("Enter your name");
            nameField.setForeground(Color.GRAY);
            // Close the greetings page and return to the cover page
            greetingsPage.setVisible(false);
            Start.setVisible(true);
        }
        });
        
        JButton menu = new JButton("Check Menu");
        menu.setBounds(48, 210, 200, 80);
        menu.setFont(new Font("Arial", Font.BOLD, 25));
        menu.setForeground(new Color(0, 0, 0)); // Black text for contrast
        menu.setFocusPainted(false);
        menu.setBorder(BorderFactory.createLineBorder(new Color(211, 211, 211), 2)); // Light Gray Border
        menu.setCursor(new Cursor(Cursor.HAND_CURSOR));
        menu.setContentAreaFilled(true);
        menu.setOpaque(true);
        greetContentPane.add(menu);
        
        menu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                greetingsPage.setVisible(false);
                showCheckMenu();
            }
        });
        
        greetingsPage.setContentPane(greetContentPane);
        greetingsPage.setSize(520, 520);
        greetingsPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        greetingsPage.setLocationRelativeTo(null); // Center the frame
        greetingsPage.setVisible(true);
        
    }
    
    public void showCheckMenu(){
        menuPage = new JFrame("Check Menu");
        
        // Load the background image
        ImageIcon backgroundIcon = new ImageIcon("C:\\MenuPage.png");
        Image backgroundImage = backgroundIcon.getImage();

        // Debug: Check if the image is loading correctly
        if (backgroundImage == null || backgroundImage.getWidth(null) == -1 || backgroundImage.getHeight(null) == -1) {
            System.out.println("Image failed to load.");
        } else {
            System.out.println("Image loaded successfully.");
        }
        
        
        // Custom contentPane with background image
        JPanel menuContentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        menuContentPane.setLayout(null);
        
        //return to greetings page
        JButton backToGreetingsPage = new JButton("<");
        backToGreetingsPage.setBounds(400, 20, 60, 30);
        backToGreetingsPage.setFont(new Font("Arial", Font.BOLD, 20));
        backToGreetingsPage.setForeground(new Color(0, 0, 0));
        backToGreetingsPage.setFocusPainted(false);
        backToGreetingsPage.setBorder(BorderFactory.createLineBorder(new Color(211, 211, 211), 2));
        backToGreetingsPage.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backToGreetingsPage.setContentAreaFilled(true);
        backToGreetingsPage.setOpaque(true);
        menuContentPane.add(backToGreetingsPage);
        
        backToGreetingsPage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuPage.setVisible(false);
                greetingsPage.setVisible(true);
            }
        });
        
        // for meals button invisible to ah
        JButton mealsButton = new JButton("");  
        mealsButton.setBounds(48,135,215,55);
        mealsButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        mealsButton.setOpaque(false); 
        mealsButton.setContentAreaFilled(false);
        mealsButton.setBorder(BorderFactory.createEmptyBorder()); 
        menuContentPane.add(mealsButton);
        
        mealsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuPage.setVisible(false);
                enteringMealMenu();
            }
        });
        
        // for dessertButton invisible to ah
        JButton dessertButton = new JButton("");
        dessertButton.setBounds(240,215,215,55);
        dessertButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        dessertButton.setOpaque(false); 
        dessertButton.setContentAreaFilled(false);
        dessertButton.setBorder(BorderFactory.createEmptyBorder()); 
        menuContentPane.add(dessertButton);
        
        dessertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               menuPage.setVisible(false);
               enteringDessertsMenu();
            }
        });
        
        // for drinks button invisible to ahh
        JButton drinkButton = new JButton("");
        drinkButton.setBounds(48,290,215,55);
        drinkButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        drinkButton.setOpaque(false); 
        drinkButton.setContentAreaFilled(false);
        drinkButton.setBorder(BorderFactory.createEmptyBorder()); 
        menuContentPane.add(drinkButton);
        
        drinkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                menuPage.setVisible(false);
                enteringDrinksMenu();  // Ensure the DrinksMenu frame is initialized
                
            }
        });
        
        menuPage.setContentPane(menuContentPane);
        menuPage.setSize(520, 520);
        menuPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menuPage.setLocationRelativeTo(null); // Center the frame
        menuPage.setVisible(true);
    }
    
    public void enteringMealMenu(){
       
    MealsMenu = new JFrame("Meals Section");
    MealsMenu.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);

    ImageIcon backgroundIcon = new ImageIcon("C:\\MealsSection.png");
    Image backgroundImage = backgroundIcon.getImage();

    JPanel mealsContentPane = new JPanel() {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    };
    mealsContentPane.setLayout(null);

    JButton backToMenuPage = createBackButton();
    backToMenuPage.addActionListener(e -> {
        MealsMenu.setVisible(false);
        menuPage.setVisible(true);
    });
    mealsContentPane.add(backToMenuPage);

    // Buttons for each meal item
    createMenuButton(mealsContentPane, "Big Mac", 4.99, 30, 105);
    createMenuButton(mealsContentPane, "Quarter Pounder with Cheese", 5.49, 183, 105);
    createMenuButton(mealsContentPane, "Chicken McNuggets", 5.69, 338, 105);
    createMenuButton(mealsContentPane, "McChicken", 3.99, 108, 265);
    createMenuButton(mealsContentPane, "Chicken Fillet", 3.49, 268, 265);

    // 'Add to Cart' button
    JButton addToCartButton = createAddToCartButton();
    mealsContentPane.add(addToCartButton);

    // 'Remove Order' button
    JButton removeOrderButton = createRemoveOrderButton();
    mealsContentPane.add(removeOrderButton);
    
    // 'View Order' button
    JButton viewOrderButton = createViewOrderButton();
    mealsContentPane.add(viewOrderButton);
    
    MealsMenu.setContentPane(mealsContentPane);
    MealsMenu.setSize(520, 520);
    MealsMenu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    MealsMenu.setLocationRelativeTo(null);
    MealsMenu.setVisible(true);
        
    }
    
    public void enteringDessertsMenu(){
    DessertsMenu = new JFrame("Desserts Section");
    DessertsMenu.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);

    ImageIcon backgroundIcon = new ImageIcon("C:\\DessertsSection.png");
    Image backgroundImage = backgroundIcon.getImage();

    JPanel dessertsContentPane = new JPanel() {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    };
    dessertsContentPane.setLayout(null);

    JButton backToMenuPage = createBackButton();
    backToMenuPage.addActionListener(e -> {
        DessertsMenu.setVisible(false);
        menuPage.setVisible(true);
    });
    dessertsContentPane.add(backToMenuPage);

    // Buttons for each dessert item
    createMenuButton(dessertsContentPane, "Apple Pie", 1.29, 32, 160);
    createMenuButton(dessertsContentPane, "McFlurry", 3.99, 187, 160);
    createMenuButton(dessertsContentPane, "Sundae", 3.99, 342, 160);

    // 'Add to Cart' button
    JButton addToCartButton = createAddToCartButton();
    dessertsContentPane.add(addToCartButton);

    // 'Remove Order' button
    JButton removeOrderButton = createRemoveOrderButton();
    dessertsContentPane.add(removeOrderButton);
    
    // 'View Order' button
    JButton viewOrderButton = createViewOrderButton();
    dessertsContentPane.add(viewOrderButton);
    
    

    DessertsMenu.setContentPane(dessertsContentPane);
    DessertsMenu.setSize(520, 520);
    DessertsMenu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    DessertsMenu.setLocationRelativeTo(null);
    DessertsMenu.setVisible(true);
        
    }
    
    public void enteringDrinksMenu(){
    DrinksMenu = new JFrame("Drinks Menu");
    DrinksMenu.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);

    ImageIcon backgroundIcon = new ImageIcon("C:\\DrinksSection.png");
    Image backgroundImage = backgroundIcon.getImage();

    JPanel drinksContentPane = new JPanel() {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    };
    drinksContentPane.setLayout(null);

    JButton backToMenuPage = createBackButton();
    backToMenuPage.addActionListener(e -> {
        DrinksMenu.setVisible(false);
        menuPage.setVisible(true);
    });
    drinksContentPane.add(backToMenuPage);

    // Buttons for each drink item
    createMenuButton(drinksContentPane, "Coca-Cola", 1.99, 93, 105);
    createMenuButton(drinksContentPane, "Sprite", 1.99, 270, 105);
    createMenuButton(drinksContentPane, "Iced Coffee", 2.19, 93, 270);
    createMenuButton(drinksContentPane, "McFloat", 2.19, 270, 270);

    // 'Add to Cart' button
    JButton addToCartButton = createAddToCartButton();
    drinksContentPane.add(addToCartButton);

    // 'Remove Order' button
    JButton removeOrderButton = createRemoveOrderButton();
    drinksContentPane.add(removeOrderButton);
    
    // 'View Order' button
    JButton viewOrderButton = createViewOrderButton();
    drinksContentPane.add(viewOrderButton); 

    DrinksMenu.setContentPane(drinksContentPane);
    DrinksMenu.setSize(520, 520);
    DrinksMenu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    DrinksMenu.setLocationRelativeTo(null);
    DrinksMenu.setVisible(true);
    }
    
    // Reusable methods to create buttons
    private JButton createMenuButton(JPanel contentPane, String itemName, double price, int x, int y) {
    JButton button = new JButton();
    button.setBounds(x, y, 135, 135);
    button.setOpaque(false);
    button.setContentAreaFilled(false);
    button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    button.addActionListener(e -> {
        selectedItem = new FoodItem(itemName, price);
        for (Component comp : contentPane.getComponents()) {
            if (comp instanceof JButton) {
                ((JButton) comp).setBorder(BorderFactory.createEmptyBorder());
            }
        }
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK));
    });
    contentPane.add(button);
    return button;
    
}

private JButton createAddToCartButton() {
    JButton addToCartButton = new JButton("");
    addToCartButton.setBounds(343, 430, 135, 35);
    addToCartButton.setOpaque(false);
    addToCartButton.setContentAreaFilled(false);
    addToCartButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    addToCartButton.setFocusPainted(false);
    addToCartButton.setBorder(BorderFactory.createEmptyBorder());
    addToCartButton.addActionListener(e -> {
        if (selectedItem != null) {
            currentCustomer.addFoodItem(selectedItem);
            JOptionPane.showMessageDialog(this, selectedItem.getName() + " added to cart!");
            displayOrderList(); // Display the updated order list
            System.out.println("Food selected: " + selectedItem);
        } else {
            JOptionPane.showMessageDialog(this, "No item selected!", "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("No Food Selected");
        }
    });
    return addToCartButton;
}

private JButton createRemoveOrderButton() {
    JButton removeOrderButton = new JButton("");
    removeOrderButton.setBounds(190, 430, 135, 35);
    removeOrderButton.setOpaque(false);
    removeOrderButton.setContentAreaFilled(false);
    removeOrderButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    removeOrderButton.setFocusPainted(false);
    removeOrderButton.setBorder(BorderFactory.createEmptyBorder());
    removeOrderButton.addActionListener(e -> {
        showRemoveOrderFrame(); // Show the remove order frame
    });
    return removeOrderButton;
}

private JButton createViewOrderButton() {
    JButton viewOrderButton = new JButton("");
    viewOrderButton.setBounds(30, 430, 135, 35);
    viewOrderButton.setFont(new Font("Arial", Font.BOLD, 15));
    viewOrderButton.setForeground(new Color(0, 0, 0)); // Black text
    viewOrderButton.setFocusPainted(false);
    viewOrderButton.setBorder(BorderFactory.createEmptyBorder()); // Light Gray Border
    viewOrderButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    viewOrderButton.setContentAreaFilled(false);
    viewOrderButton.setOpaque(false);

    viewOrderButton.addActionListener(e -> {
    JFrame currentFrame = (JFrame) SwingUtilities.getWindowAncestor(viewOrderButton);
    currentFrame.setVisible(false); // Hide the current frame instead of closing it
    showViewOrderFrame(); // Show the view order frame
});
    

    return viewOrderButton;
}

private JButton createAddMoreButton() {
    JButton AddMoreButton = new JButton("");
    AddMoreButton.setBounds(62, 440, 175, 35);
    AddMoreButton.setFont(new Font("Arial", Font.BOLD, 15));
    AddMoreButton.setForeground(new Color(0, 0, 0)); // Black text
    AddMoreButton.setFocusPainted(false);
    AddMoreButton.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 2)); // Light Gray Border
    AddMoreButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    AddMoreButton.setContentAreaFilled(false);
    AddMoreButton.setOpaque(false);
    return AddMoreButton;
}

    private JButton createProceedtoCheckOutButton() {
    JButton ProceedtoCheckOutButton = new JButton("");
    ProceedtoCheckOutButton.setBounds(265, 440, 177, 35);
    ProceedtoCheckOutButton.setFont(new Font("Arial", Font.BOLD, 15));
    ProceedtoCheckOutButton.setForeground(new Color(0, 0, 0)); // Black text
    ProceedtoCheckOutButton.setFocusPainted(false);
    ProceedtoCheckOutButton.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 2)); // Light Gray Border
    ProceedtoCheckOutButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    ProceedtoCheckOutButton.setContentAreaFilled(false);
    ProceedtoCheckOutButton.setOpaque(false);

     ProceedtoCheckOutButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (currentCustomer.getOrder().isEmpty()) {
                JOptionPane.showMessageDialog(viewOrderFrame, "You don't have any orders to proceed with.", "Error", JOptionPane.ERROR_MESSAGE);
                // Do not proceed to payment selection
            } else {
                viewOrderFrame.setVisible(false);
                showProceedToCheckOutFrame(); // Show the payment selection frame
            }
        }
    });

    return ProceedtoCheckOutButton;
}

    private JButton createProceedtoCheckOutBackButton() {
    JButton ProceedtoCheckOutBackButton = new JButton("");
    ProceedtoCheckOutBackButton.setBounds(173, 376, 153, 35);
    ProceedtoCheckOutBackButton.setFont(new Font("Arial", Font.BOLD, 15));
    ProceedtoCheckOutBackButton.setForeground(new Color(0, 0, 0)); // Black text
    ProceedtoCheckOutBackButton.setFocusPainted(false);
    ProceedtoCheckOutBackButton.setBorder(BorderFactory.createEmptyBorder()); // Light Gray Border
    ProceedtoCheckOutBackButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
    ProceedtoCheckOutBackButton.setContentAreaFilled(false);
    ProceedtoCheckOutBackButton.setOpaque(false);
    ProceedtoCheckOutBackButton.addActionListener(new ActionListener() {
            @Override
        public void actionPerformed(ActionEvent e) {
        ProceedToCheckOutFrame.setVisible(false);
        showViewOrderFrame();
        }
    });
    return ProceedtoCheckOutBackButton;
	}
	
    private JButton createProceedtoCheckOutCashButton() {
	JButton ProceedtoCheckOutCashButton = new JButton("Cash");
	ProceedtoCheckOutCashButton.setBounds(161, 169, 176, 36);
	ProceedtoCheckOutCashButton.setFont(new Font("Arial", Font.BOLD, 15));
	ProceedtoCheckOutCashButton.setForeground(new Color(0, 0, 0)); // Black text
        ProceedtoCheckOutCashButton.setFocusPainted(false);
	ProceedtoCheckOutCashButton.setBorder(BorderFactory.createEmptyBorder()); // No border
	ProceedtoCheckOutCashButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
	ProceedtoCheckOutCashButton.setContentAreaFilled(false); // Transparent background
	ProceedtoCheckOutCashButton.setOpaque(false); // Ensures transparency
            
	ProceedtoCheckOutCashButton.addActionListener(new ActionListener() {
            @Override
        public void actionPerformed(ActionEvent e) {
        ProceedToCheckOutFrame.setVisible(false);
        showCheckOutFrameCash(); // Show the checkout frame for cash
        }
        });
        // Return the button after setting up the action listener
        return ProceedtoCheckOutCashButton;
        }
                    
	
	private JButton createProceedtoCheckOutCreditCardButton() {
	    JButton ProceedtoCheckOutCreditCardButton = new JButton("Credit Card");
	    ProceedtoCheckOutCreditCardButton.setBounds(161, 235, 176, 35);
	    ProceedtoCheckOutCreditCardButton.setFont(new Font("Arial", Font.BOLD, 15));
	    ProceedtoCheckOutCreditCardButton.setForeground(new Color(0, 0, 0)); // Black text
	    ProceedtoCheckOutCreditCardButton.setFocusPainted(true);
	    ProceedtoCheckOutCreditCardButton.setBorder(BorderFactory.createEmptyBorder()); // No border
	    ProceedtoCheckOutCreditCardButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
	    ProceedtoCheckOutCreditCardButton.setContentAreaFilled(false);
	    ProceedtoCheckOutCreditCardButton.setOpaque(false);
	    ProceedtoCheckOutCreditCardButton.addActionListener(new ActionListener() {
            @Override
                 public void actionPerformed(ActionEvent e) {
                ProceedToCheckOutFrame.setVisible(false);
                showCheckOutFrameCreditCard(); // Show the checkout frame for cash
            }
        });
        // Return the button after setting up the action listener
        return ProceedtoCheckOutCreditCardButton;
	}
	
	
	private JButton createReturnToHomePageButton() {
	    JButton ProceedtoCheckOutCreditCardButton = new JButton("");
	    ProceedtoCheckOutCreditCardButton.setBounds(156, 353, 192, 35);
	    ProceedtoCheckOutCreditCardButton.setFont(new Font("Arial", Font.BOLD, 15));
	    ProceedtoCheckOutCreditCardButton.setForeground(new Color(0, 0, 0)); // Black text
	    ProceedtoCheckOutCreditCardButton.setFocusPainted(true);
	    ProceedtoCheckOutCreditCardButton.setBorder(BorderFactory.createEmptyBorder()); // No border
	    ProceedtoCheckOutCreditCardButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
	    ProceedtoCheckOutCreditCardButton.setContentAreaFilled(false);
	    ProceedtoCheckOutCreditCardButton.setOpaque(false);
	    ProceedtoCheckOutCreditCardButton.addActionListener(e -> {
            JFrame currentFrame = (JFrame) SwingUtilities.getWindowAncestor(ProceedtoCheckOutCreditCardButton);
                currentFrame.setVisible(false); // Hide the current frame instead of closing it
                coverPage();
        });
            // Return the button after setting up the action listener
	   return ProceedtoCheckOutCreditCardButton;
      }
	
	
    private JButton createBackButton() {
    JButton backToMenuPage = new JButton("<");
    backToMenuPage.setBounds(400, 20, 60, 30);
    backToMenuPage.setFont(new Font("Arial", Font.BOLD, 20));
    backToMenuPage.setForeground(new Color(0, 0, 0));
    backToMenuPage.setFocusPainted(false);
    backToMenuPage.setBorder(BorderFactory.createLineBorder(new Color(211, 211, 211), 2));
    backToMenuPage.setCursor(new Cursor(Cursor.HAND_CURSOR));
    backToMenuPage.setContentAreaFilled(true);
    backToMenuPage.setOpaque(true);
    return backToMenuPage;
    }
    
    
    private void showViewOrderFrame() {
        viewOrderFrame = new JFrame("View Order");
        viewOrderFrame.setSize(520, 520);
        viewOrderFrame.setLocationRelativeTo(null);
        viewOrderFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Background image setup
        ImageIcon backgroundIcon = new ImageIcon("C:\\ViewOrder.png");
        Image backgroundImage = backgroundIcon.getImage();

        JPanel viewOrderPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        viewOrderPane.setLayout(null);
        viewOrderFrame.setContentPane(viewOrderPane);

        JButton AddMoreButton = createAddMoreButton();
        AddMoreButton.addActionListener(e -> {
            viewOrderFrame.setVisible(false);
            menuPage.setVisible(true);
        });
        viewOrderPane.add(AddMoreButton);

        
        JButton ProceedtoCheckOutButton = createProceedtoCheckOutButton();
        ProceedtoCheckOutButton.addActionListener(e -> {
            if (currentCustomer.getOrder().isEmpty()) {
                JOptionPane.showMessageDialog(viewOrderFrame, "You don't have any orders to proceed with.", "Error", JOptionPane.ERROR_MESSAGE);
                // Do not proceed to payment selection
            } else {
                viewOrderFrame.setVisible(false);
                showProceedToCheckOutFrame(); // Show the payment selection frame
            }
        });
        viewOrderPane.add(ProceedtoCheckOutButton);


        // Order list setup with scroll pane
        JList<String> orderList = new JList<>(getCurrentOrderList());
        JScrollPane scrollPane = new JScrollPane(orderList);
        scrollPane.setBounds(60, 75, 395, 250); // Set bounds of the scroll pane
        viewOrderPane.add(scrollPane);

        // Total price label setup
        double totalPrice = calculateTotalPrice();
        JLabel totalPriceLabel = new JLabel(String.format("$%.2f", totalPrice));
        totalPriceLabel.setBounds(375, 386, 150, 30); // Positioned at the bottom right
        totalPriceLabel.setForeground(Color.BLACK); // Make text more visible
        
        totalPriceLabel.setFont(new Font("Arial", Font.BOLD, 19)); // Font, style, size

        viewOrderPane.add(totalPriceLabel);
        viewOrderFrame.setVisible(true);
        viewOrderPane.setVisible(true);
    }
    

    private void showProceedToCheckOutFrame() {
        ProceedToCheckOutFrame = new JFrame("Proceed to Checkout");
        ProceedToCheckOutFrame.setSize(520, 520);
        ProceedToCheckOutFrame.setLocationRelativeTo(null);
        ProceedToCheckOutFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Background image setup
        ImageIcon backgroundIcon = new ImageIcon("C:\\SelectPaymentType.png");
        Image backgroundImage = backgroundIcon.getImage();

        JPanel ProceedToCheckOutPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        ProceedToCheckOutPane.setLayout(null); // Set layout to null for custom positioning
        
        JButton ProceedtoCheckOutBackButton = createProceedtoCheckOutBackButton();
        ProceedToCheckOutPane.add(ProceedtoCheckOutBackButton);
        
        JButton ProceedtoCheckOutCashButton = createProceedtoCheckOutCashButton();
        ProceedToCheckOutPane.add(ProceedtoCheckOutCashButton);
        
        JButton ProceedtoCheckOutCreditCardButton = createProceedtoCheckOutCreditCardButton();
        ProceedToCheckOutPane.add(ProceedtoCheckOutCreditCardButton);

        ProceedToCheckOutFrame.setContentPane(ProceedToCheckOutPane);
        ProceedToCheckOutFrame.setVisible(true);
        ProceedToCheckOutPane.setVisible(true);
    }
    
    
    private void showCheckOutFrameCash() {
        CheckOutFrameCash = new JFrame("Cash Checkout");
        CheckOutFrameCash.setSize(520, 520);
        CheckOutFrameCash.setLocationRelativeTo(null);
        CheckOutFrameCash.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Background image setup
        ImageIcon backgroundIcon = new ImageIcon("C:\\CashPaymentPage.png");
        Image backgroundImage = backgroundIcon.getImage();

        JPanel CheckOutPaneCash = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        CheckOutPaneCash.setLayout(null); // Set layout to null for custom positioning

        // Generate a random number for the order (between 100 and 999)
        int orderNumber = ThreadLocalRandom.current().nextInt(100, 1000);
        
        // Create a JLabel to display the order number
        JLabel orderNumberLabel = new JLabel(""+orderNumber);
        orderNumberLabel.setFont(new Font("Arial", Font.BOLD, 29));
        orderNumberLabel.setForeground(Color.BLACK); // Set text color
        orderNumberLabel.setBounds(229, 221, 300, 50); // Position the label
        
        // Add the order number label to the panel
        CheckOutPaneCash.add(orderNumberLabel);

        // Add existing buttons to the panel
        JButton ReturnToHomePageButton = createReturnToHomePageButton();
        CheckOutPaneCash.add(ReturnToHomePageButton);

        // Set the panel as the content pane of the frame and display the frame
        CheckOutFrameCash.setContentPane(CheckOutPaneCash);
        CheckOutFrameCash.setVisible(true);
    }
    
    
    private void showCheckOutFrameCreditCard() {
        CheckOutFrameCard = new JFrame("Card Checkout");
        CheckOutFrameCard.setSize(520, 520);
        CheckOutFrameCard.setLocationRelativeTo(null);
        CheckOutFrameCard.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        // Background image setup
        ImageIcon backgroundIcon = new ImageIcon("C:\\CardPaymentPage.png");
        Image backgroundImage = backgroundIcon.getImage();

        JPanel CheckOutPaneCreditCard = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        CheckOutPaneCreditCard.setLayout(null); // Set layout to null for custom positioning

        // Generate a random number for the order (between 100 and 999)
        int orderNumber = ThreadLocalRandom.current().nextInt(100, 1000);
        
        // Store the order number in the Customer object
        currentCustomer.setOrderNumber(orderNumber);
        
        // Create a JLabel to display the order number
        JLabel orderNumberLabel = new JLabel(""+orderNumber);
        orderNumberLabel.setFont(new Font("Arial", Font.BOLD, 29));
        orderNumberLabel.setForeground(Color.BLACK); // Set text color
        orderNumberLabel.setBounds(229, 221, 300, 50); // Position the label
        
        // Add the order number label to the panel
        CheckOutPaneCreditCard.add(orderNumberLabel);

        // Add existing buttons to the panel
        JButton ReturnToHomePageButton = createReturnToHomePageButton();
        CheckOutPaneCreditCard.add(ReturnToHomePageButton);

        // Set the panel as the content pane of the frame and display the frame
        CheckOutFrameCard.setContentPane(CheckOutPaneCreditCard);
        CheckOutFrameCard.setVisible(true);
    }
    
    
    private void showRemoveOrderFrame() {
    // Create a new JFrame for removing an item from the order
    JFrame removeOrderFrame = new JFrame("Remove Order");
    removeOrderFrame.setLayout(new BorderLayout());
    removeOrderFrame.setSize(300, 300);
    removeOrderFrame.setLocationRelativeTo(null);
    removeOrderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    
    // Create a JList to display the current order
    JList<String> orderList = new JList<>(getCurrentOrderList());
    JScrollPane scrollPane = new JScrollPane(orderList);
    removeOrderFrame.add(scrollPane, BorderLayout.CENTER);

    // Create a button to remove the selected item
    JButton removeButton = new JButton("Remove Selected Item");
    removeButton.addActionListener(e -> {
        String selectedValue = orderList.getSelectedValue();
        if (selectedValue != null) {
            String itemName = selectedValue.split(" - ")[0];
            double itemPrice = getItemPrice(itemName);
            currentCustomer.removeFoodItem(new FoodItem(itemName, itemPrice));
            JOptionPane.showMessageDialog(removeOrderFrame, itemName + " removed from cart!");
            // Update the order list display
            orderList.setListData(getCurrentOrderList());
            System.out.println("Food removed: " + itemName);
        } else {
            JOptionPane.showMessageDialog(removeOrderFrame, "No item selected.", "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("There's no food left");
        }
    });
    removeOrderFrame.add(removeButton, BorderLayout.SOUTH);
    removeOrderFrame.setVisible(true);
}
    
    
    private double calculateTotalPrice() {
    List<FoodItem> foodItems = currentCustomer.getOrder(); // Get current order
    double totalPrice = 0;
    for (FoodItem item : foodItems) {
        totalPrice += item.getPrice(); // Add item price to total
    }
    return totalPrice;
    }
    
    
    private double getItemPrice(String itemName) {
    	for (FoodItem item : currentCustomer.getOrder()) {
        if (item.getName().equals(itemName)) {
            return item.getPrice();
        }
    }
    return 0; // Default price if not found
    }
    
    
    
    private String[] getCurrentOrderList() {
    List<FoodItem> foodItems = currentCustomer.getOrder(); // Assuming getOrder() returns List<FoodItem>
    String[] orderList = new String[foodItems.size()];

    for (int i = 0; i < foodItems.size(); i++) {
        FoodItem item = foodItems.get(i);
        orderList[i] = item.toString(); // Using toString() to get the formatted string
    }

    return orderList;
}
    
      
    private void displayOrderList() {
    List<FoodItem> order = currentCustomer.getOrder();
    String[] orderArray = new String[order.size()];
    
    for (int i = 0; i < order.size(); i++) {
        orderArray[i] = order.get(i).toString();
    }
    
    JOptionPane.showMessageDialog(this, "Current Order:\n" + String.join("\n", orderArray));
    }
    
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            McDaniels app = new McDaniels();
            app.coverPage();  // Display the cover page
        });
    }
}